#include "stdio.h"
#include "usbstk5515.h"

//#include <stdio.h>
//#include "data_types.h"
//#include "register_system.h"
//#include "register_cpu.h"
//#include "rtc.h"
//#include "control.h"
//#include "i2s_bypass1.h"
//#include "dma_bypass1.h"
//#include "ref_data_bypass.h"

extern void band_pass(void);
extern void sound_in(void);
extern void sound_out(void);
extern void startas(void);
extern void i2s_register(void);
void through();
/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  Testing Function                                                        *
 *                                                                          *
 * ------------------------------------------------------------------------ */
void TEST_execute( Int16 ( *funchandle )( ), char *testname, Int16 testid )
{
    Int16 status;

    /* Display test ID */
    printf( "%02d  Testing %s...\n", testid, testname );

    /* Call test function */
    status = funchandle( );

    /* Check for test fail */
    if ( status != 0 )
    {
        /* Print error message */
        printf( "     FAIL... error code %d... quitting\n", status );

        /* Software Breakpoint to Code Composer */
        SW_BREAKPOINT;
    }
    else
    {
        /* Print error message */
        printf( "    PASS\n" );
    }
}

extern Int16 aic3204_test( );

/* ------------------------------------------------------------------------ *
 *                                                                          *
 *  main( )                                                                 *
 *                                                                          *
 * ------------------------------------------------------------------------ */
int main( void )
{
    /* Initialize BSL */
    USBSTK5515_init( );

    printf("EXBUSSEL = %02x\n", SYS_EXBUSSEL);
    
    TEST_execute( aic3204_test, "AIC3204", 1 );

    printf( "\n***ALL Tests Passed***\n" );
    through();

        /* Disble I2S */
    //I2S0_CR = 0x00;
    //AIC3204_rset( 1, 1 );      // Reset codec
    //SW_BREAKPOINT;
}


void through()
{ 
	//enable_i2s0();
 printf( "<-> Audio Loopback from Stereo IN --> OUT\n" );
	intasm();
	while (1)
	{     
		start();	
    }

}
